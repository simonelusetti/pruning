# Implementation reference for the pruning experiments

This document records implementation-level behavior for an agent or collaborator checking the claims in the [human-facing report](supervisor_progress.md). It describes the current code, not a claim that historical figures were generated from today's Forge presets.

## Code and configuration map

| Concern | Implementation |
|:---|:---|
| Forge entry point, artifact logging | [train.py](../../train.py), [dispatch.py](../../pruning/experiments/dispatch.py), [plans.py](../../pruning/experiments/plans.py) |
| Shared Fisher strategy fields and validation | [fisher.py](../../pruning/nnprune/fisher.py) |
| Berman baseline, Classic moves, and global MIQP | [berman.py](../../pruning/experiments/berman.py) |
| OPT Fisher-aware SparseGPT and full complement | [opt_fisher.py](../../pruning/experiments/opt_fisher.py) |
| OPT factor estimation and constrained solve | [opt_b_factors.py](../../pruning/experiments/opt_b_factors.py), [factorized_fisher.py](../../pruning/nnprune/factorized_fisher.py) |

Each Forge run records its resolved configuration and result under outputs/xps/EXPERIMENT/RUN/; Forge run artifacts under outputs/xps/ are ignored by Git. The human report uses tables. The optional [OPT figure](../plots/report/opt_full_complement.png) is a retained historical figure from the completed run specified below. Its exact Forge points are also tabulated in the human report; earlier comparison values are approximate readings of retained plots.

## Optimization contract

Let $D$ contain coordinates fixed to zero, $U$ contain eligible surviving coordinates, $d=-\theta_D$, and $u=\Delta_U$. The chosen positive-semidefinite curvature estimate $F$ defines the quadratic damage $\tfrac12\Delta^\top F\Delta$. The Berman MIQP also includes $\tfrac\mu2\|u\|^2+\lambda_u|\operatorname{supp}(u)|-\lambda_dK(D)$. The OPT full-complement branch uses the Fisher quadratic plus ridge but no update-count or structural term. For fixed $D$ and unrestricted $U$, the conditional update satisfies $(F_{UU}+\mu I)u=-F_{UD}d$; conjugate gradients approximate this solve to a recorded residual tolerance. The separate choice of $D$ remains combinatorial. Generalized OBS provides a one-deletion score, not a global ranking guarantee for many simultaneous deletions. In OPT, ranking uses inverses of the damped factors, while the update objective adds a separate ridge $\mu$; this is a heuristic for the precise multi-deletion objective subsequently solved.

## Berman SimpleNN/MNIST: full-model Fisher and MIQP

The benchmark starts from the released 784–64–64–10 ReLU MLP checkpoint. We use 500 seeded training images to form a **class-marginal model Fisher** at the current weights. For each image, the code sums the probability-weighted score gradients of all ten predicted classes. Their stacked design matrix $C$ satisfies $\widehat F=C^\top C$; it retains cross-layer interactions without storing the full parameter-by-parameter matrix. It is exact for that empirical class-marginal estimate, but the 500-image estimate is still a sample of the data distribution.

Each Fisher General step constructs a *bounded* mixed-integer quadratic program:

1. **Rank deletion candidates.** For each live scalar **weight**, compute the diagonal no-update proxy $q_i=\tfrac12\theta_i^2\widehat F_{ii}$. Sort globally across the three linear layers. Partition that ordering into consecutive windows of 256 weights and retain up to eight windows. A binary decision deletes an entire window, so this is a **batched** deletion move, not one binary variable per weight. Separately, rank outgoing-weight groups of hidden units by summed diagonal cost divided by their canonicalized parameter savings; retain up to one structural group of at most 16 weights. Safeguards keep unrelated units from being removed accidentally. Biases may be updated and may disappear through canonicalization, but are not direct scalar deletion candidates.
2. **Rank update candidates.** Pool up to eight surviving coordinates, possibly including biases, by their absolute correlation with the combined deletion effect, divided by $\sqrt{\widehat F_{ii}+\mu}$. This ranking limits the search space; the subsequent MIQP evaluates interactions among the pooled coordinates.
3. **Solve jointly within that pool.** For block-selection bits $z_b$, update-selection bits $v_i$, update magnitudes $c_i$, and estimated savings $k_b$, the implemented target is

   $$
   \min_{z,v,c}\ \tfrac12\left\|
      \sum_b z_b(-C_{S_b}\theta_{S_b})+C_Uc
   \right\|_2^2
   +\tfrac{\mu}{2}\|c\|_2^2
   +\lambda_u\sum_i v_i-\lambda_d\sum_b k_bz_b.
   $$

   At least one deletion block must be selected. An indicator constraint sets $c_i=0$ when $v_i=0$; selected magnitudes have finite bounds. The current preset uses $\mu=10^{-4}$, $\lambda_u=10^{-8}$, $\lambda_d=10^{-7}$, at most 60 seconds of Gurobi time, and a 1% gap target. The solver can select multiple windows or groups in one step. The code checks the objective against a direct Fisher calculation and checks predicted structural savings against the actual canonicalizer.
4. **Evaluate and repeat.** After applying the MIQP proposal and canonicalizing, recompute the Fisher and candidate pool at the new model. The common greedy driver evaluates proposals on 2,500 MNIST examples (validation A); Fisher General currently yields one proposal per step. A separate 2,500-example split (validation B) stops and rolls back a move if its paired mean loss increase exceeds $2$ standard errors plus 5% of original loss. The remaining 5,000 examples report held-out test loss. These splits all come from MNIST's standard 10,000-example test set, so a later paper should state the split protocol explicitly.

**Berman baseline.** Our implementation recomputes the diagonal Fisher after each step, ranks *all* live parameters (including biases) by $|\theta_i|\sqrt{\widehat F_{ii}}$, and zeros enough of the lowest-ranked parameters to reach the next **global 10-percentage-point** sparsity level. It does not compensate surviving weights or optimize a structural reward. This differs both in the ranking formula and in batch size from Fisher General.

The [historical Berman comparison](../plots/berman/comparison.png) shows Fisher General at about 50% removal and $0.97\times$ original held-out loss, versus about $1.05\times$ for the plotted Berman iterative baseline. These are approximate readings from a retained figure; the old result files were not imported into Forge. The same figure includes Classic structural moves and weight-zeroing controls.

**Classic controls on Berman.** The `classic` branch proposes removal, constant replacement, or merge of hidden units. It ranks a few candidates per move family from activation moments on 4,096 training images, applies each candidate to a model copy, canonicalizes, and chooses by validation-A loss with a paired-error tie rule favoring greater savings. `classic_weights` adds single-weight zeroing candidates ranked by diagonal Fisher damage. These branches use the same validation-B stop rule and test split as Fisher General, but their candidate generation does not optimize the MIQP objective.

## OPT-125M: local $A\otimes B$ and full-complement updates

For a linear module with weight matrix $W$, the local quadratic is

$$
Q(\Delta W)=\tfrac12\operatorname{tr}(\Delta W^\top B\,\Delta W A),
\qquad A=E[aa^\top],\quad B\approx E[gg^\top],
$$

where $a$ is the module input and $g$ is its output score gradient. This is the layer-local Kronecker approximation to Fisher. The current full-curve run uses 128 C4 calibration sequences of length 2,048 for activations. For $B$, it uses the first 128 tokens of each sequence, giving **16,256 token-gradient observations** (127 predicted-token positions per sequence). It samples labels from the model's predictive distribution, accumulates their score-gradient covariance, damps $B$ by 1% of its mean diagonal, and **refreshes $B$ before each of the 12 transformer blocks**. $A$ is collected from the current block inputs and damped by 1% of its mean diagonal. Both factors are then held fixed while that block's linear modules are pruned; their within-block changes are reflected when the next block is processed.

For each linear module and each target sparsity, the retired one-shot full-complement branch:

1. Computes a generalized OBS score for every live weight,

   $$
   s_{rc}\ \propto\
   \frac{W_{rc}^{\,2}}
   {(B^{-1})_{rr}(A^{-1})_{cc}}.
   $$

   The omitted factor of $1/2$ does not affect ranking. This is the optimal *single-deletion* quadratic damage if all other coordinates may compensate. The branch takes the lowest scores to meet the module's target **once per module**, rather than choosing a new mask for each 128-column block. Multiple deletions interact, so their collective ranking is a proxy.
2. Fixes those weights at zero and lets **every surviving weight in that module** compensate. It solves the masked $A\otimes B$ quadratic with ridge $\mu=10^{-4}$ by matrix-free preconditioned conjugate gradients, to relative residual $10^{-6}$ or at most 10,000 iterations. Biases stay fixed. No structural canonicalization is applied in this configuration.
3. Processes the model block by block and evaluates the complete pruned model. Targets 10%, 20%, 30%, 40%, and 50% each start from the original checkpoint. A target is rejected if the four-sequence C4 selection loss exceeds the same paired $2$-standard-error plus 5% margin; the curve then stops. The measured removal fraction includes decoder linear biases in its denominator, although the branch does not prune them.

This differs from **Fisher-aware SparseGPT** in both deletion selection and compensation. Let $R$ be the upper Cholesky factor of the inverse of damped $A$. Fisher-aware SparseGPT ranks deletions *within each 128-input-column block* by $W_{rc}^2/[R_{cc}^2(B^{-1})_{rr}]$, then processes columns sequentially and propagates reconstruction error into later columns using $R$. Its $B$ factor affects deletion scores, but this update propagation is $A$-based. The **local SparseGPT implementation plotted in the historical OPT figure** uses $W_{rc}^2/R_{cc}^2$, without the $B^{-1}$ factor, and the same later-column propagation. It calls the project's `sparsegpt_matrix` kernel, not the separately pinned authors' program. The full-complement branch uses $(A^{-1})_{cc}$ rather than $R_{cc}^2$ in its one-shot module-wide ranking and uses both $A$ and $B$ in the continuous update solve. None of these branches globally optimizes deletion masks.

The [historical OPT comparison](../plots/opt/comparison_legacy.png) shows Fisher-aware SparseGPT below the local SparseGPT implementation in selection loss over much of the plotted range. It is **not yet a matched baseline win**: evaluation offsets, achieved removal, and canonicalization differ among saved runs. The present Forge presets also differ from some historical curve settings; the old curves cannot be assumed to describe the current presets. In a [separate 10% diagnostic](../plots/opt/b_estimation_10pct.png), the refreshed-$B$ full-complement point had 0.215% loss increase on 128 independently sampled C4 windows versus 0.255% for the Fisher-aware SparseGPT reference. Actual removal was about 9.99% versus 11.05%, so this does not isolate the update rule or establish a matched win. Other sequential $A\otimes B$ variants were better still at that point.

## Current run, comparison limits, and regeneration

The refreshed-$B$ full-complement Forge run has local signature `f1662e8f/e0357e84` (`outputs/xps/f1662e8f/e0357e84/result.json`, ignored by Git). It completed with termination_reason=loss_limit: targets 10%, 20%, and 30% were admissible; 40% was evaluated and rejected; 50% was not run. Exact (removed %, selection-loss increase %) pairs are (9.9902, 0.2340), (19.9804, 0.5911), (29.9707, 1.7836), and (39.9609, 6.7594). Every block recorded 16,256 $B$ observations and every module's conjugate-gradient residual was below $10^{-6}$. The run used a retired one-shot complement preset: float32 OPT-125M, C4 seed 0, 128 calibration sequences of 2,048 tokens, $B$ from 128-token prefixes, 1% damping on each factor, $B$ refreshed before each transformer block, $\mu=10^{-4}$, no canonicalization, and four C4 selection sequences (seed 12345). Actual removal is measured over decoder linear weights *and biases*, though biases stay fixed. Its resolved configuration remains in the local Forge run; the one-shot preset is no longer maintained.

The [Berman comparison](../plots/berman/comparison.png) and [OPT historical comparison](../plots/opt/comparison_legacy.png) are archived raster figures: their original JSON results were not imported into Forge. Values inferred from them are approximate. The historical OPT figure combines runs with different actual removal, evaluation offsets, dtype, and canonicalization. In particular, the local SparseGPT curve code uses C4 selection offset 2, while the Fisher runner uses offset 0; the old subtitle claiming identical selection splits was wrong. Both select windows from the C4 training shard with a seed distinct from calibration, rather than from a separate validation shard. The 10% $B$-estimation diagnostic used 128 independently sampled C4 windows and its full-complement result (0.215% damage, 9.99% removal) should not be treated as matched to its Fisher-aware SparseGPT reference (0.255% damage, about 11.05% removal). Its four-sequence selection point (~0.235%) agrees with the completed Forge run (0.2340%), providing a useful settings check.

The historical columns in the human report sample those raster curves at common removal levels, sometimes between plotted run points. They are descriptive approximations, not reconstructed run artifacts or independent measurements. The four nonzero OPT full-complement entries come directly from its completed Forge result; the 40% row was rejected by validation.

A retired matched-mask diagnostic compared ordinary Fisher-aware SparseGPT's $A$-based propagation with full-complement updates at the same deletion mask near 30% removal, with $\mu=0$ and $10^{-4}$. It uses the SparseGPT arm as the source of $A$, $B$, and the mask for all arms. That controls the local quadratic and mask, but later full-complement arms have their own changed activations, so held-out differences are not a completely self-consistent comparison of independently re-estimated factors. That diagnostic does not establish the cause of the observed OPT shortfall.

The maintained OPT Fisher-aware SparseGPT branch remains distinct: its blockwise deletion mask is adaptive to preceding column updates, and its updates propagate mainly with $A$. The retired one-shot full-complement branch fixed a module-wide mask once. The current progressive complement branch instead reuses the Fisher-aware SparseGPT blockwise mask at each accepted sparsity step, then optimizes every surviving weight under the selected $A\otimes B$ quadratic. At high sparsity, a lower *local quadratic* objective does not imply lower language-model loss, and single-deletion OBS scores need not assemble a good multi-deletion mask.
